# المراجعة التنفيذية للمصدر — ControlPanelNext 0.6.1

تاريخ الفحص: 2026-11-19

## نتيجة المراجعة

تمت إعادة مراجعة ملفات التطبيق الأساسية، وتشغيل `python3 tools_review.py` مرة أخرى. نجحت جميع الفحوصات الساكنة المدرجة في الأداة:

- تحليل ملفات XML.
- ربط معرفات الاختصارات بمسارات فتح إعدادات النظام.
- وجود تصنيفات الأذكار السبعة.
- وجود وظائف النسخ الاحتياطي والاستعادة والتسجيل والتذكيرات وتخصيص البطاقات وعدد الأعمدة وخياري الترتيب العشوائي والمتتابع.
- وجود حالة القائمة الفارغة، ومعاينة مكتبة الأذكار، وتأكيد الحذف الجماعي، وحماية عامل التذكير من قائمة فارغة.
- عزل شاشة المطور في نسخة المطور.
- تطابق مدخل Xposed القديم مع كلاس الـ Hook.

## تدقيق المسارات الأساسية

### التذكيرات
- الفواصل المتاحة في الواجهة: 30 و60 و120 دقيقة.
- العامل يقرأ الإعدادات والتصنيفات والأذكار المخصصة عند التنفيذ، ويتوقف بأمان إذا كان التذكير معطلًا أو لا توجد أذكار أو لم يُمنح إذن الإشعارات.
- WorkManager يضمن جدولة دورية تقريبية، وليس توقيتًا دقيقًا؛ قد تتأخر الإشعارات بسبب قيود أندرويد أو توفير الطاقة.
- عند رفض إذن الإشعارات يتم تعطيل التذكير وإلغاء العمل الدوري.

### تسجيل الشاشة
- كل جلسة تمر عبر شاشة موافقة MediaProjection من أندرويد.
- الخدمة تعمل كـ Foreground Service بنوع MediaProjection، وتعرض إجراء إيقاف في الإشعار.
- على Android 10+ يُحفظ الفيديو في `Movies/ControlPanelNext` عبر MediaStore. الإصدارات الأقدم تحفظه في مجلد Movies الخاص بالتطبيق.
- أخطاء بدء التسجيل تُسجل في Log وتظهر للمستخدم، وتُنظف الملفات غير المكتملة.
- بلاط الإعدادات السريعة يفتح التطبيق ثم يمر بموافقة أندرويد؛ لا يبدأ التسجيل سرًا.

### الإعدادات والنسخ الاحتياطي
- التصدير يحفظ إعدادات `control_panel` و`dhikr_reminders` بصيغة JSON.
- الاستيراد يقبل الأقسام المعروفة فقط ويعيد إنشاء النشاط بعد تطبيقها.
- أزرار البلوتوث والإنترنت ووضع الطيران تفتح لوحات/صفحات إعدادات النظام ولا تدّعي تبديل الحالات مباشرة.

### تكامل LSPosed
- نطاق Xposed هو `com.android.systemui`.
- مدخل Java init يشير إلى `com.controlpanel.next.hooks.SystemUiHook`.
- Hook الضبابية مشروط بـ Android 12/API 31+، ويعتمد على دعم الروم وSystemUI. لم يُختبر على جهاز فعلي.

## ما لم يمكن إثباته في هذه البيئة

- لا يوجد Gradle executable أو Gradle Wrapper في المشروع، ولا Android SDK مضبوط (`ANDROID_HOME` و`ANDROID_SDK_ROOT` غير معرفين).
- لذلك لم يتم بناء نسختي `userDebug` و`developerDebug`، ولم يتم إنتاج APK.
- لم يتم تثبيت التطبيق أو تجربة الواجهة والإشعارات والتسجيل على هاتف فعلي.
- فحص Kotlin السابق لم ينتج أخطاء تحليل نحوي، لكنه أظهر مراجع Android/AndroidX/Xposed غير محلولة بسبب غياب SDK والمكتبات؛ وهذا ليس نجاحًا لترجمة المشروع كاملًا.

## الحكم النهائي

المصدر اجتاز الفحوصات الساكنة المذكورة ومراجعة مساراته الأساسية، لكن لا يصح وصفه بأنه APK مبني أو مختبر أو مضمون الخلو من الأعطال. الخطوة اللازمة لاعتماد الإصدار هي البناء في Android Studio أو CI، ثم تثبيت النسختين واختبارهما على جهاز فعلي، بما في ذلك توافق LSPosed وOne UI.

## جولة تحقق إضافية

أُجريت جولة تحقق إضافية بعد المراجعة السابقة:
- نجح تحليل جميع ملفات XML مرة أخرى.
- تم التحقق من أن أصناف Activity/Service/Provider المشار إليها في Manifest لها ملفات Kotlin مصدرية.
- تم التحقق من تطابق مهام CI مع product flavors المعلنة (`user` و`developer`) ومع إصدار التطبيق 0.6.1.
- تم التحقق من وجود تصاريح وخدمات تسجيل الشاشة والإشعارات وبلاطة الإعدادات السريعة في Manifest.
- اجتاز ملف ZIP اختبار سلامة الأرشيف.

لم يتغير حكم البناء: تعذر الاتصال بمستودع Gradle من بيئة التنفيذ، ولا يتوفر Android SDK أو Gradle محليًا؛ لذلك لا يوجد APK ولا اختبار تشغيل فعلي. هذه الجولة لا تستبدل بناء Android أو الاختبار على الهاتف.


## إصلاح إضافي بعد جولة المراجعة السابقة

- عولجت حالة عدم اتساق WorkManager بعد استعادة نسخة احتياطية تكون فيها تذكيرات الذكر معطلة: أصبح `onResume()` يلغي العمل الدوري القديم صراحةً عندما تكون قيمة `enabled=false`.
- أضيف فحص انحدار في `tools_review.py` للتحقق من وجود هذا الإلغاء.
- أعيد تشغيل `tools_review.py` ونجح بجميع فحوصاته.
- أعيد فحص ملفات Kotlin عبر `kotlinc`: لم تظهر أخطاء تحليل نحوي، لكن الترجمة الكاملة لا تزال متعذرة بسبب عدم توفر Android/AndroidX/Xposed classpath وAndroid SDK؛ لذلك لا يُعد ذلك بناءً ناجحًا.
- لم يتغير وضع APK: لم يُبنَ ولم يُختبر على جهاز حقيقي.

## جولة تحقق إضافية: تسجيل الشاشة والبناء الآلي

أُضيفت فحوصات انحدار ساكنة لمسار تسجيل الشاشة والتذكيرات، وتشمل:
- وجود صلاحية `FOREGROUND_SERVICE_MEDIA_PROJECTION` ونوع الخدمة `mediaProjection` في Manifest.
- تسجيل `MediaProjection.Callback` للتعامل مع إيقاف جلسة الإسقاط.
- وجود إجراء إيقاف في إشعار التسجيل.
- إنشاء ملف MediaStore كعنصر Pending ثم نشره بعد نجاح التسجيل.
- حصر فواصل التذكير في النطاق المدعوم ووجود اختيارات 30 و60 و120 دقيقة في الواجهة.

كما تم تحديث GitHub Actions لتشغيل فحوصات المصدر قبل البناء، والتحقق من وجود ملفي APK غير فارغين بعد البناء، وإضافة تعليمات البناء المحلي وتشغيل CI إلى README.

النتيجة: جميع فحوصات `tools_review.py` الحالية نجحت. لم يُنفذ بناء Gradle في هذه البيئة، ولم يتم تثبيت APK أو اختبار تسجيل الشاشة وLSPosed على جهاز حقيقي؛ لذلك تظل هذه مراجعة مصدرية وليست اعتمادًا تشغيليًا.

## جولة إصلاح إضافية — استيراد النسخ الاحتياطية

تم إصلاح مسار استيراد JSON في `MainActivity`:
- أصبح تحليل أقسام `control_panel` و`dhikr_reminders` والتحقق من أنواع جميع القيم يتم قبل تعديل SharedPreferences.
- يتم رفض الأقسام غير الصالحة والقيم غير المدعومة وعناصر القوائم التي ليست نصوصًا، بدل مسح الإعدادات ثم تجاهل القيم غير المفهومة.
- أصبح الحفظ يستخدم `commit()` مع التحقق من نجاحه قبل إعلان نجاح الاستيراد.
- أضيفت فحوصات ارتدادية لهذه الشروط إلى `tools_review.py`.

نتائج الجولة:
- نجحت جميع اختبارات `tools_review.py` بعد إضافة اختبارات الاستيراد.
- نجح تحليل جميع ملفات XML.
- لم يُظهر فحص Kotlin أخطاء تحليل نحوي؛ بقيت مراجع Android وAndroidX وXposed غير قابلة للحل في هذه البيئة لغياب SDK والمكتبات، لذلك لا يُعد ذلك بناءً ناجحًا.
- لم يتم بناء APK أو تثبيته أو اختباره على جهاز فعلي.

ملاحظة: يتم التحقق من الملف كاملًا قبل الكتابة، لكن SharedPreferences لملفي الإعدادات لا توفر معاملة ذرية مشتركة؛ لذلك لا يمكن ضمان التراجع التلقائي عن القسم الأول إذا فشل حفظ القسم الثاني بسبب خطأ تخزين نادر.


## Follow-up review — 2026-11-19

- Fixed reminder scheduling behavior: Activity resume now uses `ExistingPeriodicWorkPolicy.KEEP` via `ensureScheduled`, so opening the app does not reset the periodic reminder countdown. Explicit user setting changes still use `UPDATE` to apply the selected interval.
- Backup restore now reconciles the reminder worker immediately after importing preferences, including cancellation when disabled or notification permission is unavailable.
- Screen-capture service teardown now deletes an incomplete pending MediaStore output if the service is destroyed during setup before recording starts.
- Added static regression checks for non-resetting reminder reconciliation and cleanup of incomplete recording output on teardown.
- `python3 tools_review.py` passes after these changes. These are source-level checks; Android build and device runtime tests remain pending due to missing Android SDK/Gradle in this environment.

## Additional recording reliability fix (2026-11-19)
- Screen recording now closes the MediaStore output file descriptor before clearing `IS_PENDING`, preventing the gallery from seeing a still-open/incompletely flushed output.
- A failed MediaStore publish is logged and the incomplete row is deleted instead of silently leaving a broken video.
- Stop success now requires a non-null active `MediaRecorder` and a successful `stop()` call; it can no longer report success merely because a nullable recorder call did nothing.
- Added static regression checks for descriptor-close-before-publish, stop validation, and failed-publication cleanup.
- `python3 tools_review.py`: all checks pass.
- Still not performed: full Android Gradle build, APK generation, device recording test, or LSPosed runtime test.

## Follow-up review — transactional backup restore (2026-11-19)

- Fixed a partial-restore failure mode: the complete backup is parsed first, then the existing values for every affected preference file are snapshotted before any write.
- Preference writes are centralized in `applyPreferenceValues`; if a later preference commit fails, the importer attempts to restore all snapshots instead of leaving an intentionally partial restore.
- String-set values are checked before writing, including when restoring the in-memory snapshot.
- Added regression guards in `tools_review.py` for snapshot-before-write and rollback-on-failure behavior.
- Validation run: `python3 tools_review.py` passed; `python3 -m py_compile tools_review.py` passed.
- This remains source/static validation. It is not an Android Gradle build or a device test.


## Follow-up review — MediaStore publish result

- The recording finalization path now checks that `ContentResolver.update(... IS_PENDING=0 ...)` updates at least one row. A zero-row result is treated as a failure, logged, and the incomplete MediaStore entry is deleted.
- Added a regression check in `tools_review.py` for this case.
- This is a source-level fix; Android build and device validation remain outstanding.

## Follow-up review — 2026-11-19 (recording startup hardening)

- Replaced force-unwrapped MediaProjection/output references in the screen-recording startup path with checked local references.
- Added validation for display width, height, and density before configuring MediaRecorder; dimensions are normalized once to even video dimensions and reused for both recorder and VirtualDisplay.
- Added an explicit failure path when output creation yields neither a file descriptor nor a file path.
- Extended `tools_review.py` with regression checks for these guards and the absence of the previous force unwraps.
- `python3 tools_review.py` passes after the changes; `python3 -m py_compile tools_review.py` passes.
- This remains static/source validation only. No Android Gradle build, APK install, MediaProjection runtime test, or LSPosed device test was performed in this environment.


## Follow-up: duplicate screen-recording start guard (2026-11-19)

The recording service now rejects a second `ACTION_START` while a recording or MediaProjection session is already active. This prevents repeated Quick Settings tile taps from overwriting active recorder/projection references. A static regression assertion covers the guard. This is source-level validation only; runtime behavior still requires device testing.


## Follow-up: legacy recording output validation (2026-11-19)

For Android versions below API 29, the service now verifies that the app-owned MP4 exists and has a nonzero length after `MediaRecorder.stop()`. Empty output is treated as a failed recording, discarded, and reported to the user instead of being counted as a successful save. A static regression assertion covers this guard. Device/runtime validation remains pending.


## Follow-up review — exported settings-provider boundary (2026-11-19)

- Added regression checks for the exported ContentProvider used by SystemUI: its CRUD write methods remain inert, its callable read is restricted to the blur-settings method, and the returned blur radius is clamped to 0–100.
- This protects the deliberately exported cross-process bridge from accidentally growing into a general settings-write surface.
- Static checks pass; no Android runtime/security test has been performed.

## Follow-up review — SystemUI bridge caller authentication (2026-11-19)

- Hardened the exported `PanelSettingsProvider`: it now checks the Binder caller UID's package list and returns settings only when the caller UID includes `com.android.systemui` and the requested method is the single supported blur-settings read.
- Unauthorized callers and unknown methods receive `Bundle.EMPTY`; provider CRUD write operations remain inert, and the blur radius remains clamped to 0–100.
- Hardened `SystemUiHook` refresh throttling: the one-second refresh timestamp is now advanced before attempting the provider call, so a failing bridge cannot generate a log entry for every blur operation.
- Added static regression checks for caller authentication, empty unauthorized responses, and failure-path throttling.
- Validation: `python3 tools_review.py` passed; `python3 -m py_compile tools_review.py` passed.
- Scope limitation: these are source-level checks. No Android build, Binder runtime/security test, LSPosed test, or Samsung One UI device test was performed.

## Follow-up review — Quick Settings tile and flavor integration (2026-11-19)

- Added regression coverage for the screen-recording Quick Settings tile: SystemUI binding permission/action, exported tile service, activity handoff, and the explicit MediaProjection consent request before the foreground recording service starts.
- Added a consistency check that the manifest provider authority (`${applicationId}.settings`) matches the LSPosed hook URI built from the flavor-specific `BuildConfig.APPLICATION_ID`.
- Confirmed user and developer variants retain distinct application ID suffixes.
- Validation: `python3 tools_review.py` passed all checks; `python3 -m py_compile tools_review.py` passed.
- Scope: this adds source-level integration guards only. No Gradle build, APK output, Quick Settings runtime test, MediaProjection device test, or LSPosed/Samsung One UI test was performed.

## Follow-up review — fail-closed blur bridge (2026-11-19)

- Hardened `SystemUiHook` so a failed settings-provider refresh explicitly disables the cached blur value and resets the cached radius to the default, rather than continuing to apply a stale enabled preference indefinitely.
- The one-second refresh throttle remains in place, so the fail-closed behavior does not reintroduce per-operation log spam.
- Added a static regression assertion for the provider-failure fail-closed path.
- Validation: `python3 tools_review.py` passed all checks; `python3 -m py_compile tools_review.py` passed.
- Scope: source-level validation only. No Gradle build, APK generation, Binder runtime test, LSPosed test, or physical-device test was performed.

## Follow-up review — MediaProjection teardown re-entry guard (2026-11-19)

- Found a teardown race in screen recording: releasing a `MediaProjection` can invoke its registered `onStop()` callback, which calls `stopRecording()`.
- The failed-start cleanup path and the non-recording `onDestroy()` path previously released the projection without first marking teardown as active. The callback could therefore re-enter cleanup while the original cleanup was still running.
- Both paths now set the existing `stopping` guard before releasing the projection. A subsequent callback returns immediately through the existing idempotency guard.
- Added regression checks requiring the guard to be set before `releaseCapture()` in both paths.
- Validation: `python3 tools_review.py` passed all checks; `python3 -m py_compile tools_review.py` passed.
- Scope: source/static validation only. Android Gradle build, APK generation, and runtime MediaProjection/LSPosed device tests remain outstanding.

## Packaging consistency review — 2026-11-19

The previous source archive included both the canonical project at its root and a stale nested `ControlPanelNext/` copy. The nested copy differed in `SystemUiHook.kt`, `ScreenCaptureService.kt`, and `tools_review.py`, and did not contain the latest fail-closed blur and teardown regression checks. This created ambiguity about which source tree should be opened or built. The deliverable has been normalized to one root project and Python bytecode caches have been excluded. The canonical root project passes all current static regression checks and Python syntax validation. This does not constitute a Gradle build or Android runtime test.

## Follow-up review — build pipeline consistency (2026-11-19)

- Added static regression checks that the root plugin versions (AGP 8.7.3 / Kotlin 2.0.21), app SDK levels (compileSdk 35 / minSdk 26), product flavors, CI Gradle 8.9 setup, Android 35 platform install, both assemble tasks, APK existence checks, and artifact uploads remain aligned.
- All source regression checks, XML parsing, and Python syntax validation pass.
- Attempted to obtain the Gradle 8.9 distribution for a local build, but this execution environment cannot resolve `services.gradle.org` (DNS/network unavailable). No Android SDK is installed either. Therefore no APK build or device test is claimed.

## Follow-up review — CI least-privilege and reliability (2026-11-19)

- Restricted the workflow's repository token to `contents: read` because the build only checks out source and uploads run artifacts; it does not write repository contents.
- Added a concurrency group that cancels superseded runs for the same workflow/ref, avoiding unnecessary parallel Android builds.
- Added a 35-minute job timeout and explicitly provisions Python 3.x before running the source regression script.
- Extended `tools_review.py` to assert these CI safeguards.
- Validation: all `tools_review.py` checks pass; `python3 -m py_compile tools_review.py` passes.
- This is a workflow/source review only. The workflow has not yet run on GitHub, and no APK build or device test is claimed.
