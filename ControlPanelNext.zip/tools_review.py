from pathlib import Path
import re, xml.etree.ElementTree as ET
root = Path(__file__).parent
errors=[]
# XML well-formedness
for f in root.rglob('*.xml'):
    try: ET.parse(f)
    except Exception as e: errors.append(f'XML {f}: {e}')
main=(root/'app/src/main/java/com/controlpanel/next/MainActivity.kt').read_text()
worker=(root/'app/src/main/java/com/controlpanel/next/reminders/DhikrReminderWorker.kt').read_text()
catalog=(root/'app/src/main/java/com/controlpanel/next/reminders/DhikrCatalog.kt').read_text()
# Every action surfaced in the dashboard must have a dispatch branch.
actions=set(re.findall(r'QuickAction\([^\n]*?,\s*"([a-z]+)"\)', main))
branches=set(re.findall(r'"([a-z]+)"\s*->', main))
for action in sorted(actions-branches): errors.append(f'Unmapped quick action: {action}')
# Ensure all categories contain actual nonempty entries.
for key in ['tasbeeh','istighfar','hamd','tahlil','hawqala','salawat','dua']:
    if f'"{key}" to listOf(' not in catalog: errors.append(f'Missing dhikr category: {key}')
# Ensure important UI flows exist.
for token in ['تصدير نسخة احتياطية','استعادة نسخة احتياطية','تسجيل الشاشة','تذكير بالذكر','بطاقات مدمجة','عدد أعمدة الاختصارات','ترتيب الأذكار عشوائيًا','استعراض مكتبة الأذكار','حذف الكل','AlertDialog']:
    if token not in main: errors.append(f'Missing UI item: {token}')
if 'if (pool.isEmpty()) return Result.success()' not in worker: errors.append('Worker lacks empty-pool guard')
# Restoring a backup with reminders disabled must cancel any previously scheduled periodic work.
on_resume = main.split('override fun onResume()', 1)[1].split('private fun readBrightness()', 1)[0]
if 'else {\n            // Keep WorkManager state in sync' not in on_resume or 'DhikrReminderScheduler.cancel(this)' not in on_resume:
    errors.append('Disabled reminders do not cancel previously scheduled WorkManager work on resume')
if 'customPhrases.isEmpty()' not in main: errors.append('Custom phrase empty state missing')
# Backup import must validate every value before clearing or writing preferences.
if 'parseBackupSettings(JSONObject(raw))' not in main: errors.append('Backup import does not parse/validate before applying')
if 'private fun parseBackupSettings(root: JSONObject)' not in main: errors.append('Backup validation helper missing')
if 'require(item is String)' not in main: errors.append('Backup string-set entries are not type-checked')
if 'else -> error("قيمة غير مدعومة: $key")' not in main: errors.append('Unsupported backup values are not rejected')
if 'check(editor.commit())' not in main: errors.append('Backup import does not check preference commit result')
if 'val snapshots = restored.keys.associateWith' not in main: errors.append('Backup import does not snapshot existing preferences before applying')
if 'catch (failure: Throwable)' not in main or 'applyPreferenceValues(name, values)' not in main: errors.append('Backup import does not attempt rollback after a failed preference write')
if 'private fun applyPreferenceValues(name: String, values: Map<String, *>)' not in main: errors.append('Shared preference apply/rollback helper missing')
if errors:
    print('\n'.join('FAIL: '+e for e in errors)); raise SystemExit(1)
print('PASS: XML files parse')
print('PASS: all quick-action IDs map to system-setting handlers')
print('PASS: all seven dhikr categories are present')
print('PASS: backup, recording, reminders, compact mode, columns, random/sequential options exist')
print('PASS: empty custom phrase state, catalog preview, confirmed bulk deletion, and worker empty-pool guard exist')
print('PASS: backup data is fully validated before preferences are changed')
print('Quick actions checked:', ', '.join(sorted(actions)))

# Edition isolation and LSPosed entrypoint integrity.
manifest_dev=(root/'app/src/developer/AndroidManifest.xml').read_text()
user_manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
if 'DeveloperConsoleActivity' not in manifest_dev: errors.append('Developer activity missing from developer manifest')
if 'DeveloperConsoleActivity' in user_manifest: errors.append('Developer activity leaked into main manifest')
if not (root/'app/src/developer/java/com/controlpanel/next/developer/DeveloperConsoleActivity.kt').exists(): errors.append('Developer activity source missing')
if (root/'app/src/user/java/com/controlpanel/next/developer/DeveloperConsoleActivity.kt').exists(): errors.append('Developer activity source leaked into user source set')
entry=(root/'app/src/main/assets/xposed_init').read_text().strip()
if entry != 'com.controlpanel.next.hooks.SystemUiHook': errors.append('Legacy Xposed entrypoint mismatch')
if not (root/'app/src/main/java/com/controlpanel/next/hooks/SystemUiHook.kt').exists(): errors.append('Xposed hook class missing')
if errors:
    print('FAIL: edition isolation or Xposed entrypoint check')
    raise SystemExit(1)
print('PASS: developer console is isolated to developer source/manifest')
print('PASS: legacy Xposed entrypoint resolves to the hook class')

# Screen-recording and reminder integration regression checks.
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
recording=(root/'app/src/main/java/com/controlpanel/next/recording/ScreenCaptureService.kt').read_text()
scheduler=(root/'app/src/main/java/com/controlpanel/next/reminders/DhikrReminderScheduler.kt').read_text()
if 'android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION' not in manifest:
    errors.append('MediaProjection foreground-service permission missing')
if 'android:foregroundServiceType="mediaProjection"' not in manifest:
    errors.append('Screen capture service lacks mediaProjection foreground type')
if 'MediaProjection.Callback()' not in recording or 'registerCallback' not in recording:
    errors.append('MediaProjection stop callback is not registered')
if 'cleanupOutput(deleteIncomplete = true)' not in recording.split('override fun onDestroy()', 1)[1]:
    errors.append('Service teardown can leave an incomplete pending video behind')
if 'ACTION_STOP' not in recording or 'addAction' not in recording:
    errors.append('Screen recording notification has no stop action')
if 'MediaStore.Video.Media.IS_PENDING, 1' not in recording or 'MediaStore.Video.Media.IS_PENDING, 0' not in recording:
    errors.append('MediaStore pending output is not finalized after recording')
cleanup = recording.split('private fun cleanupOutput(deleteIncomplete: Boolean)', 1)[1].split('private fun createNotificationChannel()', 1)[0]
if cleanup.find('outputDescriptor?.close()') < 0 or cleanup.find('outputDescriptor?.close()') > cleanup.find('MediaStore.Video.Media.IS_PENDING, 0'):
    errors.append('Recorded file is published before its output descriptor is closed')
if 'activeRecorder != null && runCatching { activeRecorder.stop(); true }' not in recording:
    errors.append('Recording stop can report success without a live MediaRecorder')
if 'Unable to publish recorded video' not in recording or 'contentResolver.delete(uri, null, null)' not in cleanup:
    errors.append('Failed MediaStore publication is not logged and cleaned up')
if 'check(updatedRows > 0)' not in cleanup:
    errors.append('MediaStore zero-row publication result is not treated as failure')
if 'projection!!' in recording or 'outputDescriptor!!' in recording or 'file!!' in recording:
    errors.append('Screen recording still contains unsafe non-null assertions')
if 'Invalid display dimensions' not in recording or 'No recording output was created' not in recording:
    errors.append('Screen recording does not validate display/output before starting')
if 'if (recording || projection != null)' not in recording or 'Ignoring duplicate screen-recording start request' not in recording:
    errors.append('Screen recording does not reject duplicate start requests while a session is active')
failure_cleanup = recording.split('catch (t: Throwable)', 1)[1].split('private data class Output', 1)[0]
destroy_cleanup = recording.split('override fun onDestroy()', 1)[1]
if failure_cleanup.find('stopping = true') < 0 or failure_cleanup.find('stopping = true') > failure_cleanup.find('releaseCapture()'):
    errors.append('Failed recording startup can re-enter teardown from the MediaProjection stop callback')
if destroy_cleanup.find('stopping = true') < 0 or destroy_cleanup.find('stopping = true') > destroy_cleanup.find('releaseCapture()'):
    errors.append('Service destruction can re-enter teardown from the MediaProjection stop callback')
if 'val legacyFileValid = Build.VERSION.SDK_INT >= 29' not in recording or 'it.isFile && it.length() > 0L' not in recording:
    errors.append('Legacy screen-recording output is not checked for a nonempty file before success')
if 'coerceIn(30, 120)' not in scheduler:
    errors.append('Reminder interval is not bounded to supported range')
if 'ExistingPeriodicWorkPolicy.KEEP' not in scheduler or 'fun ensureScheduled' not in scheduler:
    errors.append('Activity resume can reset the reminder countdown instead of preserving scheduled work')
if 'DhikrReminderScheduler.ensureScheduled(this, reminders.getInt("interval_minutes", 120))' not in on_resume:
    errors.append('Activity resume does not use non-resetting reminder reconciliation')
if 'listOf(30 to "نصف ساعة", 60 to "ساعة", 120 to "ساعتان")' not in main:
    errors.append('Reminder UI does not expose 30/60/120 minute intervals')
if errors:
    print('FAIL: recording/reminder integration checks')
    raise SystemExit(1)
print('PASS: MediaProjection permission, foreground type, callback, stop action, descriptor-close-before-publish, and failure cleanup')
print('PASS: MediaProjection callback cannot re-enter failed-start or service-destroy teardown')
print('PASS: reminder interval bounds and 30/60/120-minute choices')

# The exported provider is the narrow bridge used by SystemUI; it must remain read-only.
provider=(root/'app/src/main/java/com/controlpanel/next/PanelSettingsProvider.kt').read_text()
if 'override fun insert' not in provider or 'override fun delete' not in provider or 'override fun update' not in provider:
    errors.append('Settings provider CRUD surface is incomplete')
for signature in ['override fun insert(uri: Uri, values: ContentValues?): Uri? = null',
                  'override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0',
                  'override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0']:
    if signature not in provider: errors.append('Settings provider unexpectedly permits a write operation')
if 'prefs?.getInt(KEY_BLUR_RADIUS, 28)?.coerceIn(0, 100)' not in provider:
    errors.append('Settings provider does not clamp blur radius returned to SystemUI')
if 'method != METHOD_GET_BLUR' not in provider:
    errors.append('Settings provider does not restrict reads to the known blur-settings method')
if 'Binder.getCallingUid()' not in provider or 'getPackagesForUid' not in provider or 'SYSTEM_UI_PACKAGE = \"com.android.systemui\"' not in provider:
    errors.append('Exported settings provider does not authenticate the SystemUI caller')
if 'if (!isSystemUiCaller() || method != METHOD_GET_BLUR) return Bundle.EMPTY' not in provider:
    errors.append('Unauthorized provider calls do not receive an empty response')
hook=(root/'app/src/main/java/com/controlpanel/next/hooks/SystemUiHook.kt').read_text()
refresh=hook.split('if (now - lastReload >= PREF_REFRESH_MS)', 1)[1].split('if (enabled)', 1)[0]
if refresh.find('lastReload = now') < 0 or refresh.find('lastReload = now') > refresh.find('runCatching'):
    errors.append('SystemUI hook does not throttle failed settings-provider refreshes')
if 'enabled = false' not in refresh or 'blur disabled' not in refresh:
    errors.append('SystemUI hook does not fail closed when the settings provider refresh fails')
if errors:
    print('FAIL: settings-provider access-boundary checks')
    raise SystemExit(1)
print('PASS: exported SystemUI settings bridge is read-only, radius-bounded, and restricted to SystemUI UID')
print('PASS: SystemUI hook throttles failed provider refreshes to avoid log spam')

# Quick Settings tile must route through the activity so Android's MediaProjection
# consent dialog is shown before the foreground capture service is started.
tile=(root/'app/src/main/java/com/controlpanel/next/ScreenRecordTileService.kt').read_text()
if 'startActivityAndCollapse(launch)' not in tile or 'EXTRA_FROM_TILE' not in tile:
    errors.append('Screen-recording Quick Settings tile does not route to the consent activity')
if 'android.permission.BIND_QUICK_SETTINGS_TILE' not in manifest or 'android.service.quicksettings.action.QS_TILE' not in manifest:
    errors.append('Quick Settings tile manifest binding/action is incomplete')
if 'android:exported="true"' not in manifest.split('android:name=".ScreenRecordTileService"', 1)[1].split('/>', 1)[0]:
    errors.append('Quick Settings tile service is not exported for SystemUI binding')
if 'handleTileLaunch(intent)' not in main or 'captureLauncher.launch(manager.createScreenCaptureIntent())' not in main:
    errors.append('Tile launch does not request MediaProjection user consent')
if 'ContextCompat.startForegroundService(this, start)' not in main:
    errors.append('Consent result does not start the capture foreground service')
if 'android:authorities="${applicationId}.settings"' not in manifest or 'BuildConfig.APPLICATION_ID}.settings' not in hook:
    errors.append('Provider authority and flavor-specific hook URI can diverge')
if 'applicationIdSuffix = ".user"' not in (root/'app/build.gradle.kts').read_text() or 'applicationIdSuffix = ".developer"' not in (root/'app/build.gradle.kts').read_text():
    errors.append('User/developer application IDs are not isolated')
if errors:
    print('FAIL: Quick Settings and flavor integration checks')
    raise SystemExit(1)
print('PASS: Quick Settings tile requests explicit MediaProjection consent before starting capture')
print('PASS: flavor-specific provider authority matches the LSPosed hook application ID')

# Build pipeline consistency: keep the local Gradle project and CI build matrix aligned.
root_build = (root/'build.gradle.kts').read_text()
app_build = (root/'app/build.gradle.kts').read_text()
workflow = (root/'.github/workflows/android-build.yml').read_text()
checks = [
    ('Android Gradle Plugin 8.7.3', 'com.android.application") version "8.7.3' in root_build),
    ('Kotlin plugins 2.0.21', 'org.jetbrains.kotlin.android") version "2.0.21' in root_build and 'org.jetbrains.kotlin.plugin.compose") version "2.0.21' in root_build),
    ('compileSdk 35 and minSdk 26', 'compileSdk = 35' in app_build and 'minSdk = 26' in app_build),
    ('user and developer build flavors', 'create("user")' in app_build and 'create("developer")' in app_build),
    ('CI uses Gradle 8.9 and Android platform 35', "gradle-version: '8.9'" in workflow and "platforms;android-35" in workflow),
    ('CI has read-only repository permissions and bounded concurrency', 'permissions:\n  contents: read' in workflow and 'cancel-in-progress: true' in workflow),
    ('CI pins a Python runtime and has a job timeout', 'actions/setup-python@v5' in workflow and 'timeout-minutes: 35' in workflow),
    ('CI assembles both debug flavors', ':app:assembleUserDebug :app:assembleDeveloperDebug' in workflow),
    ('CI verifies and uploads both APK outputs', 'app-user-debug.apk' in workflow and 'app-developer-debug.apk' in workflow and workflow.count('actions/upload-artifact@v4') >= 2),
]
for label, ok in checks:
    if not ok: errors.append('Build pipeline mismatch: ' + label)
if errors:
    print('FAIL: build pipeline consistency checks')
    raise SystemExit(1)
for label, _ in checks:
    print('PASS: ' + label)
