package com.controlpanel.next.developer

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.controlpanel.next.BuildConfig

/** Developer-only diagnostics screen. No user-edition source or manifest entry includes this class. */
class DeveloperConsoleActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!BuildConfig.DEVELOPER_EDITION) { finish(); return }
        setContent {
            MaterialTheme {
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("لوحة المطوّر", style = MaterialTheme.typography.headlineMedium)
                    Text("إصدار المطوّر: ${BuildConfig.VERSION_NAME}")
                    Text("معرّف الحزمة: ${BuildConfig.APPLICATION_ID}")
                    Text("هذه الشاشة محلية للتشخيص. إحصائيات المستخدمين عن بُعد ونشر الإعلانات تتطلب خادمًا موثوقًا وحساب إدارة؛ لم يتم تفعيل تتبع أو جمع بيانات دون موافقة.")
                    OutlinedButton(onClick = { finish() }) { Text("إغلاق") }
                }
            }
        }
    }
}
