package com.controlpanel.next

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.Binder
import android.os.Bundle

/** Exposes only non-sensitive SystemUI tuning values to the LSPosed process. */
class PanelSettingsProvider : ContentProvider() {
    override fun onCreate(): Boolean = true
    override fun getType(uri: Uri): String? = "vnd.android.cursor.item/vnd.controlpanel.settings"
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle {
        // The provider is exported only because SystemUI runs under a different UID.
        // Do not expose even these tuning values to arbitrary third-party apps.
        if (!isSystemUiCaller() || method != METHOD_GET_BLUR) return Bundle.EMPTY

        val prefs = context?.getSharedPreferences("control_panel", android.content.Context.MODE_PRIVATE)
        return Bundle().apply {
            putBoolean(KEY_BLUR_ENABLED, prefs?.getBoolean(KEY_BLUR_ENABLED, false) ?: false)
            putInt(KEY_BLUR_RADIUS, prefs?.getInt(KEY_BLUR_RADIUS, 28)?.coerceIn(0, 100) ?: 28)
        }
    }

    private fun isSystemUiCaller(): Boolean {
        val callerPackages = context?.packageManager?.getPackagesForUid(Binder.getCallingUid())
        return callerPackages?.contains(SYSTEM_UI_PACKAGE) == true
    }

    companion object {
        private const val SYSTEM_UI_PACKAGE = "com.android.systemui"
        const val AUTHORITY_SUFFIX = ".settings"
        const val METHOD_GET_BLUR = "get_blur_settings"
        const val KEY_BLUR_ENABLED = "live_blur_enabled"
        const val KEY_BLUR_RADIUS = "live_blur_radius"
    }
}
