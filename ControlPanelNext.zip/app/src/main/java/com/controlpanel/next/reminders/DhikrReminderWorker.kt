package com.controlpanel.next.reminders

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/** Posts one gentle reminder; the user controls its frequency and categories. */
class DhikrReminderWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return Result.success()

        if (Build.VERSION.SDK_INT >= 33 &&
            applicationContext.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return Result.success()

        val enabled = prefs.getStringSet("categories", DEFAULT_CATEGORIES)?.toSet() ?: DEFAULT_CATEGORIES
        val custom = prefs.getStringSet("custom_phrases", emptySet())?.toSet() ?: emptySet()
        val pool = DhikrCatalog.phrases(enabled, custom)
        if (pool.isEmpty()) return Result.success()

        createChannel()
        val randomOrder = prefs.getBoolean("random_order", true)
        val index = if (randomOrder) {
            kotlin.random.Random.nextInt(pool.size)
        } else {
            val current = prefs.getInt("next_phrase_index", 0).coerceAtLeast(0)
            prefs.edit().putInt("next_phrase_index", (current + 1) % pool.size).apply()
            current % pool.size
        }
        val dhikr = pool[index]
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("تذكير بالذكر")
            .setContentText(dhikr)
            .setStyle(NotificationCompat.BigTextStyle().bigText("خذ لحظة للذكر 🌿\n$dhikr"))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .build()

        runCatching { NotificationManagerCompat.from(applicationContext).notify(NOTIFICATION_ID, notification) }
        return Result.success()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = applicationContext.getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(CHANNEL_ID, "تذكير بالذكر", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "تذكيرات التسبيح والاستغفار والحمد والتهليل والحوقلة والأدعية والصلاة على النبي ﷺ"
            }
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val PREFS = "dhikr_reminders"
        const val CHANNEL_ID = "dhikr_reminders"
        const val NOTIFICATION_ID = 8401
        val DEFAULT_CATEGORIES = setOf("tasbeeh", "istighfar", "hamd", "tahlil", "hawqala", "salawat", "dua")
    }
}
