package com.controlpanel.next

import android.content.Intent
import android.service.quicksettings.TileService

/** Optional Android Quick Settings tile; the activity still requests user consent. */
class ScreenRecordTileService : TileService() {
    override fun onClick() {
        super.onClick()
        val launch = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(EXTRA_FROM_TILE, true)
        }
        startActivityAndCollapse(launch)
    }

    companion object {
        const val EXTRA_FROM_TILE = "com.controlpanel.next.EXTRA_FROM_TILE"
    }
}
