package com.controlpanel.next.reminders

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object DhikrReminderScheduler {
    private const val UNIQUE_WORK = "control_panel_dhikr_reminders"

    fun schedule(context: Context, intervalMinutes: Int) {
        val safeInterval = intervalMinutes.coerceIn(30, 120)
        val request = PeriodicWorkRequestBuilder<DhikrReminderWorker>(safeInterval.toLong(), TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.NOT_REQUIRED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            UNIQUE_WORK,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    /** Ensure a reminder exists without resetting the countdown on every Activity resume. */
    fun ensureScheduled(context: Context, intervalMinutes: Int) {
        val safeInterval = intervalMinutes.coerceIn(30, 120)
        val request = PeriodicWorkRequestBuilder<DhikrReminderWorker>(safeInterval.toLong(), TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.NOT_REQUIRED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            UNIQUE_WORK,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK)
    }
}
