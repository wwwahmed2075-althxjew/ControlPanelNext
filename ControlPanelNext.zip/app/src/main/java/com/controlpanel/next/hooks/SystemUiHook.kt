package com.controlpanel.next.hooks

import android.os.Build
import android.os.SystemClock
import android.net.Uri
import de.robv.android.xposed.AndroidAppHelper
import com.controlpanel.next.BuildConfig
import android.view.Window
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * LSPosed entry point loaded inside SystemUI.
 * The hook is installed even when blur is initially disabled, so changing the
 * module preference takes effect without reinstalling the module. SystemUI may
 * still need to recreate its windows before every surface reflects the change.
 */
class SystemUiHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != SYSTEM_UI) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            XposedBridge.log("ControlPanelNext: live window blur requires Android 12/API 31+")
            return
        }

        try {
            var lastReload = 0L
            var enabled = false
            var radius = 0

            XposedHelpers.findAndHookMethod(
                Window::class.java,
                "setBackgroundBlurRadius",
                Int::class.javaPrimitiveType!!,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val now = SystemClock.uptimeMillis()
                        if (now - lastReload >= PREF_REFRESH_MS) {
                            // Throttle failed provider calls too; otherwise a broken bridge
                            // can emit one log entry for every SystemUI blur operation.
                            lastReload = now
                            runCatching {
                                val app = AndroidAppHelper.currentApplication()
                                val values = app?.contentResolver?.call(
                                    SETTINGS_URI,
                                    "get_blur_settings",
                                    null,
                                    null
                                )
                                enabled = values?.getBoolean(KEY_BLUR_ENABLED, false) ?: false
                                radius = values?.getInt(KEY_BLUR_RADIUS, 28)?.coerceIn(0, 100) ?: 28
                            }.onFailure {
                                // Fail closed: if the bridge disappears or rejects the call,
                                // do not keep applying a previously enabled blur indefinitely.
                                enabled = false
                                radius = 28
                                XposedBridge.log("ControlPanelNext: preference refresh failed; blur disabled: ${it.message}")
                            }
                        }
                        if (enabled) param.args[0] = radius
                    }
                }
            )
            XposedBridge.log("ControlPanelNext: SystemUI blur hook installed; preferences refresh dynamically")
        } catch (t: Throwable) {
            XposedBridge.log("ControlPanelNext: SystemUI hook failed: ${t.javaClass.name}: ${t.message}")
        }
    }

    companion object {
        private const val SYSTEM_UI = "com.android.systemui"
        private val SETTINGS_URI = Uri.parse("content://${BuildConfig.APPLICATION_ID}.settings")
        private const val KEY_BLUR_ENABLED = "live_blur_enabled"
        private const val KEY_BLUR_RADIUS = "live_blur_radius"
        private const val PREF_REFRESH_MS = 1_000L
    }
}
