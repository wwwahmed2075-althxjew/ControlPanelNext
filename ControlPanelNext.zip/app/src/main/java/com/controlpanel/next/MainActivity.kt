package com.controlpanel.next

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.media.AudioManager
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Monitor
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.AirplanemodeActive
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.controlpanel.next.recording.ScreenCaptureService
import com.controlpanel.next.reminders.DhikrReminderScheduler
import com.controlpanel.next.reminders.DhikrCatalog
import org.json.JSONObject

private val Night = Color(0xFF101116)
private val Panel = Color(0xFF222630)
private val Accent = Color(0xFF8EA7FF)

class MainActivity : ComponentActivity() {
    private var writeSettingsGranted by mutableStateOf(false)

    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val prefs = getSharedPreferences("dhikr_reminders", MODE_PRIVATE)
        if (granted && prefs.getBoolean("enabled", false)) {
            DhikrReminderScheduler.schedule(this, prefs.getInt("interval_minutes", 120))
        } else if (!granted) {
            prefs.edit().putBoolean("enabled", false).apply()
            DhikrReminderScheduler.cancel(this)
            recreate()
        }
    }

    private val exportSettingsLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching {
            val root = JSONObject()
            listOf("control_panel", "dhikr_reminders").forEach { name ->
                val prefs = getSharedPreferences(name, MODE_PRIVATE)
                val values = JSONObject()
                prefs.all.forEach { (key, value) ->
                    when (value) {
                        is Boolean -> values.put(key, value)
                        is Int -> values.put(key, value)
                        is Long -> values.put(key, value)
                        is Float -> values.put(key, value.toDouble())
                        is String -> values.put(key, value)
                        is Set<*> -> values.put(key, org.json.JSONArray(value.filterIsInstance<String>()))
                    }
                }
                root.put(name, values)
            }
            val output = contentResolver.openOutputStream(uri) ?: error("تعذر فتح ملف النسخة الاحتياطية")
            output.bufferedWriter().use { it.write(root.toString(2)) }
            android.widget.Toast.makeText(this, "تم تصدير الإعدادات بنجاح", android.widget.Toast.LENGTH_SHORT).show()
        }.onFailure {
            android.widget.Toast.makeText(this, "فشل التصدير: ${it.localizedMessage ?: "خطأ غير معروف"}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
    private val importSettingsLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("ملف فارغ")
            val restored = parseBackupSettings(JSONObject(raw))
            // Validate the complete backup before changing preferences, then keep
            // snapshots so a failed write cannot leave a half-restored configuration.
            val snapshots = restored.keys.associateWith { name ->
                getSharedPreferences(name, MODE_PRIVATE).all.toMap()
            }
            try {
                restored.forEach { (name, values) -> applyPreferenceValues(name, values) }
            } catch (failure: Throwable) {
                snapshots.forEach { (name, values) ->
                    runCatching { applyPreferenceValues(name, values) }
                }
                throw failure
            }
            val reminderPrefs = getSharedPreferences("dhikr_reminders", MODE_PRIVATE)
            if (reminderPrefs.getBoolean("enabled", false)) {
                val notificationsAllowed = Build.VERSION.SDK_INT < 33 ||
                    checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (notificationsAllowed) {
                    DhikrReminderScheduler.schedule(this, reminderPrefs.getInt("interval_minutes", 120))
                } else {
                    reminderPrefs.edit().putBoolean("enabled", false).apply()
                    DhikrReminderScheduler.cancel(this)
                }
            } else {
                DhikrReminderScheduler.cancel(this)
            }
            android.widget.Toast.makeText(this, "تم استيراد الإعدادات بنجاح", android.widget.Toast.LENGTH_SHORT).show()
            recreate()
        }.onFailure {
            android.widget.Toast.makeText(this, "تعذر استيراد الملف: ${it.localizedMessage ?: "صيغة غير صحيحة"}", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private fun applyPreferenceValues(name: String, values: Map<String, *>) {
        val editor = getSharedPreferences(name, MODE_PRIVATE).edit().clear()
        values.forEach { (key, value) ->
            when (value) {
                is Boolean -> editor.putBoolean(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Float -> editor.putFloat(key, value)
                is String -> editor.putString(key, value)
                is Set<*> -> {
                    require(value.all { it is String }) { "قائمة إعدادات غير صالحة: $key" }
                    editor.putStringSet(key, value.filterIsInstance<String>().toSet())
                }
                else -> error("نوع إعداد غير مدعوم: $key")
            }
        }
        check(editor.commit()) { "تعذر حفظ إعدادات $name" }
    }

    private fun parseBackupSettings(root: JSONObject): Map<String, Map<String, Any>> {
        val sections = listOf("control_panel", "dhikr_reminders")
        val present = sections.filter(root::has)
        require(present.isNotEmpty()) { "الملف لا يحتوي على إعدادات معروفة" }
        return present.associateWith { name ->
            val values = root.optJSONObject(name) ?: error("قسم الإعدادات غير صالح: $name")
            buildMap {
                values.keys().forEach { key ->
                    val value = values.get(key)
                    val parsed: Any = when (value) {
                        is Boolean, is Int, is Long, is String -> value
                        is Double -> value.toFloat()
                        is org.json.JSONArray -> buildSet {
                            for (index in 0 until value.length()) {
                                val item = value.get(index)
                                require(item is String) { "قائمة غير صالحة: $key" }
                                add(item)
                            }
                        }
                        else -> error("قيمة غير مدعومة: $key")
                    }
                    put(key, parsed)
                }
            }
        }
    }

    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val start = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
            }
            androidx.core.content.ContextCompat.startForegroundService(this, start)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        writeSettingsGranted = Settings.System.canWrite(this)
        setContent {
            @Suppress("DEPRECATION")
            val modulePrefs = remember { getSharedPreferences("control_panel", MODE_PRIVATE) }
            var dark by remember { mutableStateOf(modulePrefs.getBoolean("dark_mode", true)) }
            var blurEnabled by remember { mutableStateOf(modulePrefs.getBoolean("live_blur_enabled", false)) }
            var blurRadius by remember { mutableFloatStateOf(modulePrefs.getInt("live_blur_radius", 28).toFloat()) }
            val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
            var brightness by remember { mutableFloatStateOf(readBrightness()) }
            var volume by remember { mutableFloatStateOf(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)) }
            val scheme = if (dark) darkColorScheme(primary = Accent, background = Night, surface = Panel)
                else lightColorScheme(primary = Color(0xFF4059A8))
            MaterialTheme(colorScheme = scheme) {
                ControlPanelScreen(
                    dark = dark,
                    onThemeChange = { dark = it; modulePrefs.edit().putBoolean("dark_mode", it).apply() },
                    blurEnabled = blurEnabled,
                    blurRadius = blurRadius,
                    onBlurEnabledChange = { blurEnabled = it; modulePrefs.edit().putBoolean("live_blur_enabled", it).apply() },
                    onBlurRadiusChange = { blurRadius = it; modulePrefs.edit().putInt("live_blur_radius", it.toInt()).apply() },
                    brightness = brightness,
                    volume = volume,
                    writeSettingsGranted = writeSettingsGranted,
                    onBrightnessChange = { value ->
                        brightness = value
                        if (Settings.System.canWrite(this)) {
                            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, (value * 255).toInt().coerceIn(1, 255))
                        }
                    },
                    onVolumeChange = { value ->
                        volume = value
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (value * audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).toInt(), 0)
                    },
                    onRequestWriteSettings = {
                        val permissionIntent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
                        runCatching { startActivity(permissionIntent) }
                    },
                    onRecord = {
                        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        captureLauncher.launch(manager.createScreenCaptureIntent())
                    },
                    onOpenSettings = { action -> openSystemPanel(action) },
                    onOpenDeveloperConsole = {
                        if (BuildConfig.DEVELOPER_EDITION) runCatching {
                            startActivity(Intent().setClassName(packageName, "com.controlpanel.next.developer.DeveloperConsoleActivity"))
                        }
                    },
                    onExportSettings = { exportSettingsLauncher.launch("ControlPanelNext-settings.json") },
                    onImportSettings = { importSettingsLauncher.launch(arrayOf("application/json", "text/*")) },
                    onDhikrReminderChange = { enabled, intervalMinutes, categories ->
                        val prefs = getSharedPreferences("dhikr_reminders", MODE_PRIVATE)
                        prefs.edit()
                            .putBoolean("enabled", enabled)
                            .putInt("interval_minutes", intervalMinutes)
                            .putStringSet("categories", categories)
                            .apply()
                        if (enabled) {
                            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                DhikrReminderScheduler.schedule(this, intervalMinutes)
                            }
                        } else {
                            DhikrReminderScheduler.cancel(this)
                        }
                    }
                )
            }
        }
        window.decorView.post { handleTileLaunch(intent) }
    }

    override fun onResume() {
        super.onResume()
        writeSettingsGranted = Settings.System.canWrite(this)
        val reminders = getSharedPreferences("dhikr_reminders", MODE_PRIVATE)
        if (reminders.getBoolean("enabled", false)) {
            val notificationsAllowed = Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (notificationsAllowed) {
                DhikrReminderScheduler.ensureScheduled(this, reminders.getInt("interval_minutes", 120))
            } else {
                reminders.edit().putBoolean("enabled", false).apply()
                DhikrReminderScheduler.cancel(this)
            }
        } else {
            // Keep WorkManager state in sync after restoring a backup that disabled reminders.
            DhikrReminderScheduler.cancel(this)
        }
    }

    private fun readBrightness(): Float {
        val value = runCatching { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) }.getOrDefault(160)
        return (value / 255f).coerceIn(0f, 1f)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        window.decorView.post { handleTileLaunch(intent) }
    }

    private fun handleTileLaunch(source: Intent?) {
        if (source?.getBooleanExtra(ScreenRecordTileService.EXTRA_FROM_TILE, false) == true) {
            source.removeExtra(ScreenRecordTileService.EXTRA_FROM_TILE)
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            captureLauncher.launch(manager.createScreenCaptureIntent())
        }
    }

    private fun openSystemPanel(action: String) {
        val intent = when (action) {
            "brightness" -> if (android.os.Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_BRIGHTNESS) else Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "sound" -> if (android.os.Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_VOLUME) else Intent(Settings.ACTION_SOUND_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "app" -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            "notifications" -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            "internet" -> if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIFI_SETTINGS)
            "airplane" -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        runCatching { startActivity(intent) }.onFailure { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
}

private data class QuickAction(val title: String, val detail: String, val icon: ImageVector, val action: String)

@Composable
private fun ControlPanelScreen(
    dark: Boolean,
    onThemeChange: (Boolean) -> Unit,
    blurEnabled: Boolean,
    blurRadius: Float,
    onBlurEnabledChange: (Boolean) -> Unit,
    onBlurRadiusChange: (Float) -> Unit,
    brightness: Float,
    volume: Float,
    writeSettingsGranted: Boolean,
    onBrightnessChange: (Float) -> Unit,
    onVolumeChange: (Float) -> Unit,
    onRequestWriteSettings: () -> Unit,
    onRecord: () -> Unit,
    onOpenSettings: (String) -> Unit,
    onOpenDeveloperConsole: () -> Unit,
    onExportSettings: () -> Unit,
    onImportSettings: () -> Unit,
    onDhikrReminderChange: (Boolean, Int, Set<String>) -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    val reminderContext = LocalContext.current
    val reminderPrefs = remember { reminderContext.getSharedPreferences("dhikr_reminders", android.content.Context.MODE_PRIVATE) }
    var remindersEnabled by remember { mutableStateOf(reminderPrefs.getBoolean("enabled", false)) }
    var reminderInterval by remember { mutableIntStateOf(reminderPrefs.getInt("interval_minutes", 120).let { if (it in setOf(30, 60, 120)) it else 120 }) }
    var randomDhikrOrder by remember { mutableStateOf(reminderPrefs.getBoolean("random_order", true)) }
    var reminderCategories by remember {
        mutableStateOf(reminderPrefs.getStringSet("categories", setOf("tasbeeh", "istighfar", "hamd", "tahlil", "hawqala", "salawat", "dua"))?.toSet()
            ?: setOf("tasbeeh", "istighfar", "hamd", "tahlil", "hawqala", "salawat", "dua"))
    }
    val controlPrefs = remember { reminderContext.getSharedPreferences("control_panel", android.content.Context.MODE_PRIVATE) }
    var compactCards by remember { mutableStateOf(controlPrefs.getBoolean("compact_cards", false)) }
    var gridColumns by remember { mutableIntStateOf(controlPrefs.getInt("grid_columns", 2).coerceIn(2, 3)) }
    val cardPadding = if (compactCards) 11.dp else 16.dp
    val actions = listOf(
        QuickAction("السطوع", "إعدادات سطوع الشاشة", Icons.Default.Brightness6, "brightness"),
        QuickAction("الصوت", "مستوى الصوت", Icons.Default.VolumeUp, "sound"),
        QuickAction("بلوتوث", "إعدادات البلوتوث", Icons.Default.Bluetooth, "bluetooth"),
        QuickAction("الواي فاي", "إعدادات الشبكة والإنترنت", Icons.Default.Wifi, "internet"),
        QuickAction("الشاشة", "إعدادات العرض", Icons.Default.Monitor, "display"),
        QuickAction("وضع الطيران", "إعدادات الشبكة ووضع الطيران", Icons.Default.AirplanemodeActive, "airplane"),
        QuickAction("الوسائط", "إعدادات الصوت والوسائط", Icons.Default.MusicNote, "sound")
    )
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("لوحة التحكم", style = MaterialTheme.typography.headlineMedium,
                        modifier = Modifier.combinedClickable(onClick = {}, onLongClick = onOpenDeveloperConsole))
                    Text("اختصاراتك وإعداداتك في مكان واحد", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { tab = 1 }) { Icon(Icons.Default.Settings, contentDescription = "الإعدادات") }
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("الرئيسية") }, leadingIcon = { Icon(Icons.Default.Tune, null) })
                FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("التخصيص") })
                FilterChip(selected = tab == 2, onClick = { tab = 2 }, label = { Text("الإشعارات") })
            }
            Spacer(Modifier.height(16.dp))
            if (tab == 0) {
                Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("التحكم السريع", style = MaterialTheme.typography.titleLarge)
                        Text("تحكم مباشر في مستوى السطوع وصوت الوسائط.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("سطوع الشاشة", style = MaterialTheme.typography.labelLarge)
                        Slider(value = brightness, onValueChange = onBrightnessChange, enabled = writeSettingsGranted)
                        if (!writeSettingsGranted) {
                            OutlinedButton(onClick = onRequestWriteSettings, modifier = Modifier.fillMaxWidth()) { Text("السماح بالتحكم في سطوع الشاشة") }
                        }
                        Text("صوت الوسائط", style = MaterialTheme.typography.labelLarge)
                        Slider(value = volume, onValueChange = onVolumeChange)
                    }
                }
                Spacer(Modifier.height(14.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(gridColumns), modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(actions) { item ->
                        Card(onClick = { onOpenSettings(item.action) }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(Modifier.fillMaxWidth().padding(cardPadding), verticalArrangement = Arrangement.spacedBy(if (compactCards) 5.dp else 9.dp)) {
                                Icon(item.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Text(item.title, style = MaterialTheme.typography.titleMedium)
                                Text(item.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    item {
                        Card(onClick = onRecord, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                            Column(Modifier.fillMaxWidth().padding(cardPadding), verticalArrangement = Arrangement.spacedBy(if (compactCards) 5.dp else 9.dp)) {
                                Icon(Icons.Default.Monitor, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                Text("تسجيل الشاشة", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                Text("ابدأ بعد موافقة أندرويد", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                        }
                    }
                }
            } else if (tab == 1) {
                Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("المظهر", style = MaterialTheme.typography.titleLarge)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("الوضع الداكن", Modifier.weight(1f))
                            Switch(checked = dark, onCheckedChange = onThemeChange)
                        }
                        HorizontalDivider()
                        Text("كثافة واجهة التطبيق", style = MaterialTheme.typography.titleMedium)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("بطاقات مدمجة")
                                Text("تقليل المسافات داخل أزرار الصفحة الرئيسية", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = compactCards, onCheckedChange = {
                                compactCards = it
                                controlPrefs.edit().putBoolean("compact_cards", it).apply()
                            })
                        }
                        Text("عدد أعمدة الاختصارات", style = MaterialTheme.typography.labelLarge)
                        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                            (2..3).forEachIndexed { index, count ->
                                SegmentedButton(
                                    selected = gridColumns == count,
                                    onClick = { gridColumns = count; controlPrefs.edit().putInt("grid_columns", count).apply() },
                                    shape = SegmentedButtonDefaults.itemShape(index = index, count = 2)
                                ) { Text("$count أعمدة") }
                            }
                        }
                        Text("ملاحظة: هذه الخيارات تخص واجهة التطبيق. تعديل لوحة النظام الأصلية وحجم بلاطاتها يحتاج Hooks متوافقة مع إصدار One UI وSystemUI، ولم أفعّل تحكمًا وهميًا بها.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        HorizontalDivider()
                        Text("حفظ واستعادة إعداداتك", style = MaterialTheme.typography.titleMedium)
                        OutlinedButton(onClick = onExportSettings, modifier = Modifier.fillMaxWidth()) { Text("تصدير نسخة احتياطية") }
                        OutlinedButton(onClick = onImportSettings, modifier = Modifier.fillMaxWidth()) { Text("استعادة نسخة احتياطية") }
                        OutlinedButton(onClick = { onOpenSettings("app") }, modifier = Modifier.fillMaxWidth()) { Text("فتح معلومات التطبيق") }
                        HorizontalDivider()
                        Text("تأثيرات SystemUI عبر LSPosed", style = MaterialTheme.typography.titleMedium)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("ضبابية خلفية النوافذ")
                                Text("تُطبّق على النوافذ التي تستخدم واجهة Android للضبابية", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = blurEnabled, onCheckedChange = onBlurEnabledChange)
                        }
                        Text("قوة الضبابية: ${blurRadius.toInt()}", style = MaterialTheme.typography.labelLarge)
                        Slider(value = blurRadius, onValueChange = onBlurRadiusChange, valueRange = 0f..100f, enabled = blurEnabled)
                        Text("بعد تغيير الإعدادات، أعد تشغيل SystemUI أو الجهاز لتأكيد تطبيقها. يعتمد التأثير على دعم الروم والشركة المصنّعة.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    }
                }
            } else {
                Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        HorizontalDivider()
                        Text("تذكير بالذكر", style = MaterialTheme.typography.titleLarge)
                        Text("إشعار لطيف يظهر في إشعارات الهاتف كل فترة تختارها، ويحتوي على ذكر أو صلاة على النبي ﷺ.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("تفعيل تذكير الذكر")
                                Text("يمكنك إيقافه في أي وقت", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = remindersEnabled, onCheckedChange = {
                                remindersEnabled = it
                                onDhikrReminderChange(it, reminderInterval, reminderCategories)
                            })
                        }
                        Text("تكرار التذكير", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(30 to "نصف ساعة", 60 to "ساعة", 120 to "ساعتان").forEach { (minutes, label) ->
                                FilterChip(selected = reminderInterval == minutes, onClick = {
                                    reminderInterval = minutes
                                    if (remindersEnabled) onDhikrReminderChange(true, reminderInterval, reminderCategories)
                                }, label = { Text(label) }, enabled = remindersEnabled)
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("ترتيب الأذكار عشوائيًا")
                                Text("أوقفه لعرض الأذكار بالتتابع", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(checked = randomDhikrOrder, enabled = remindersEnabled, onCheckedChange = {
                                randomDhikrOrder = it
                                reminderPrefs.edit().putBoolean("random_order", it).apply()
                            })
                        }
                        Text("أنواع الأذكار", style = MaterialTheme.typography.labelLarge)
                        val categoryOptions = listOf(
                            "tasbeeh" to "تسبيح",
                            "istighfar" to "استغفار",
                            "hamd" to "حمد وشكر",
                            "tahlil" to "التهليل",
                            "hawqala" to "الحوقلة",
                            "salawat" to "الصلاة على النبي ﷺ",
                            "dua" to "الأدعية"
                        )
                        categoryOptions.forEach { (key, label) ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(label, Modifier.weight(1f))
                                Checkbox(checked = key in reminderCategories, enabled = remindersEnabled, onCheckedChange = { checked ->
                                    reminderCategories = if (checked) reminderCategories + key else reminderCategories - key
                                    if (reminderCategories.isEmpty()) reminderCategories = setOf(key)
                                    if (remindersEnabled) onDhikrReminderChange(true, reminderInterval, reminderCategories)
                                })
                            }
                        }
                        var customPhrase by remember { mutableStateOf("") }
                        var customPhrases by remember { mutableStateOf(reminderPrefs.getStringSet("custom_phrases", emptySet())?.toSet() ?: emptySet()) }
                        var confirmClearCustom by remember { mutableStateOf(false) }
                        var showLibrary by remember { mutableStateOf(false) }
                        Text("أضف ذكرًا أو دعاءً من اختيارك", style = MaterialTheme.typography.labelLarge)
                        OutlinedTextField(value = customPhrase, onValueChange = { customPhrase = it.take(300) }, modifier = Modifier.fillMaxWidth(), label = { Text("اكتب الذكر أو الدعاء") }, supportingText = { Text("${customPhrase.length}/300") }, singleLine = false)
                        OutlinedButton(onClick = {
                            val phrase = customPhrase.trim()
                            if (phrase.isNotEmpty() && phrase !in customPhrases) {
                                customPhrases = customPhrases + phrase
                                reminderPrefs.edit().putStringSet("custom_phrases", customPhrases).apply()
                                customPhrase = ""
                                if (remindersEnabled) onDhikrReminderChange(true, reminderInterval, reminderCategories)
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("إضافة إلى قائمة التذكير") }
                        if (customPhrases.isEmpty()) {
                            Text("لم تضف أذكارًا مخصصة بعد. يمكنك كتابة ذكر أو دعاء بالأعلى وسيظهر هنا.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("الأذكار المخصصة (${customPhrases.size})", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
                                TextButton(onClick = { confirmClearCustom = true }) { Text("حذف الكل") }
                            }
                        }
                        customPhrases.sorted().forEach { phrase ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(phrase, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                TextButton(onClick = {
                                    customPhrases = customPhrases - phrase
                                    reminderPrefs.edit().putStringSet("custom_phrases", customPhrases).apply()
                                    if (remindersEnabled) onDhikrReminderChange(true, reminderInterval, reminderCategories)
                                }) { Text("حذف") }
                            }
                        }
                        OutlinedButton(onClick = { showLibrary = !showLibrary }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (showLibrary) "إخفاء مكتبة الأذكار" else "استعراض مكتبة الأذكار (${DhikrCatalog.categories.values.sumOf { it.size }} عبارة)")
                        }
                        if (showLibrary) {
                            val categoryLabels = mapOf(
                                "tasbeeh" to "التسبيح", "istighfar" to "الاستغفار", "hamd" to "الحمد والشكر",
                                "tahlil" to "التهليل", "hawqala" to "الحوقلة", "salawat" to "الصلاة على النبي ﷺ", "dua" to "الأدعية"
                            )
                            DhikrCatalog.categories.forEach { (key, phrases) ->
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("${categoryLabels[key] ?: key} • ${phrases.size}", style = MaterialTheme.typography.titleSmall)
                                    phrases.take(3).forEach { phrase ->
                                        Text("• $phrase", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                HorizontalDivider()
                            }
                        }
                        if (confirmClearCustom) {
                            AlertDialog(
                                onDismissRequest = { confirmClearCustom = false },
                                title = { Text("حذف الأذكار المخصصة؟") },
                                text = { Text("سيتم حذف ${customPhrases.size} عبارة أضفتها بنفسك. لا يمكن التراجع عن هذه الخطوة.") },
                                confirmButton = {
                                    TextButton(onClick = {
                                        customPhrases = emptySet()
                                        reminderPrefs.edit().remove("custom_phrases").apply()
                                        confirmClearCustom = false
                                    }) { Text("حذف الكل") }
                                },
                                dismissButton = { TextButton(onClick = { confirmClearCustom = false }) { Text("إلغاء") } }
                            )
                        }
                        Text("مواعيد الإشعارات تقريبية؛ قد يؤخر أندرويد التذكير بسبب وضع توفير الطاقة أو قيود النظام.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedButton(onClick = { onOpenSettings("notifications") }, modifier = Modifier.fillMaxWidth()) {
                            Text("إعدادات إشعارات التطبيق")
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("لوحة التحكم • الإصدار 0.6.1", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}
