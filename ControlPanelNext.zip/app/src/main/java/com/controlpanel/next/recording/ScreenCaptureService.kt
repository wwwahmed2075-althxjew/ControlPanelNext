package com.controlpanel.next.recording

import android.app.*
import android.content.pm.ServiceInfo
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.controlpanel.next.MainActivity
import com.controlpanel.next.R
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Screen recording service. Android's MediaProjection consent is always required. */
class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var outputUri: Uri? = null
    private var outputFile: File? = null
    private var outputDescriptor: android.os.ParcelFileDescriptor? = null
    private var recording = false
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopRecording(); return START_NOT_STICKY }
            ACTION_START -> {
                // A second tile tap must not create another MediaProjection/recorder
                // while the current capture session is already active.
                if (recording || projection != null) {
                    android.util.Log.w("ControlPanelNext", "Ignoring duplicate screen-recording start request")
                    return START_NOT_STICKY
                }
                stopping = false
                createNotificationChannel()
                val startingNotification = notification("جارٍ تجهيز التسجيل")
                if (Build.VERSION.SDK_INT >= 29) {
                    startForeground(NOTIFICATION_ID, startingNotification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
                } else {
                    startForeground(NOTIFICATION_ID, startingNotification)
                }
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                @Suppress("DEPRECATION")
                val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                                    else intent.getParcelableExtra(EXTRA_DATA)
                if (resultCode != Activity.RESULT_OK || data == null) {
                    android.widget.Toast.makeText(this, "لم تتم الموافقة على تسجيل الشاشة", android.widget.Toast.LENGTH_SHORT).show()
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    return START_NOT_STICKY
                }
                startCapture(resultCode, data)
            }
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun startCapture(resultCode: Int, data: Intent) {
        try {
            createNotificationChannel()
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi
            check(width >= 2 && height >= 2 && density > 0) { "Invalid display dimensions" }
            val videoWidth = width - (width % 2)
            val videoHeight = height - (height % 2)
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val activeProjection = manager.getMediaProjection(resultCode, data)
                ?: error("Unable to create MediaProjection")
            projection = activeProjection
            activeProjection.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopRecording() }
            }, null)

            val output = createOutput()
            outputUri = output.uri
            outputFile = output.file
            outputDescriptor = output.descriptor
            val mr = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            recorder = mr
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            mr.setVideoEncodingBitRate(8_000_000)
            mr.setVideoFrameRate(30)
            mr.setVideoSize(videoWidth, videoHeight)
            val descriptor = output.descriptor
            val outputFilePath = output.file?.absolutePath
            when {
                descriptor != null -> mr.setOutputFile(descriptor.fileDescriptor)
                outputFilePath != null -> mr.setOutputFile(outputFilePath)
                else -> error("No recording output was created")
            }
            mr.prepare()
            virtualDisplay = activeProjection.createVirtualDisplay(
                "ControlPanelNext-Recording", videoWidth, videoHeight, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, mr.surface, null, null
            )
            mr.start()
            recording = true
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification("يتم تسجيل الشاشة الآن"))
        } catch (t: Throwable) {
            android.util.Log.e("ControlPanelNext", "Screen recording failed", t)
            android.widget.Toast.makeText(this, "تعذر بدء تسجيل الشاشة: ${t.localizedMessage ?: "خطأ غير معروف"}", android.widget.Toast.LENGTH_LONG).show()
            recording = false
            // MediaProjection.stop() can invoke the registered onStop callback.
            // Mark teardown as in-progress first so that callback cannot re-enter
            // stopRecording() while this failure path is already releasing resources.
            stopping = true
            cleanupOutput(deleteIncomplete = true)
            releaseCapture()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private data class Output(val descriptor: android.os.ParcelFileDescriptor?, val uri: Uri?, val file: File?)
    private fun createOutput(): Output {
        val name = "ControlPanel_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.mp4"
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ControlPanelNext")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Unable to create video entry")
            try {
                val descriptor = contentResolver.openFileDescriptor(uri, "w") ?: error("Unable to open video")
                Output(descriptor, uri, null)
            } catch (t: Throwable) {
                runCatching { contentResolver.delete(uri, null, null) }
                throw t
            }
        } else {
            @Suppress("DEPRECATION")
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
            if (!dir.exists()) dir.mkdirs()
            Output(null, null, File(dir, name))
        }
    }

    private fun stopRecording() {
        if (stopping) return
        stopping = true
        val recorderStopped = if (recording) {
            val activeRecorder = recorder
            activeRecorder != null && runCatching { activeRecorder.stop(); true }.getOrDefault(false)
        } else false
        // On Android versions that write to an app-owned File, MediaRecorder.stop()
        // can return without producing a usable payload (for example after a very
        // short/failed capture). Never report that empty file as a saved recording.
        val legacyFileValid = Build.VERSION.SDK_INT >= 29 ||
            (outputFile?.let { it.isFile && it.length() > 0L } == true)
        val saved = recorderStopped && legacyFileValid
        if (recorderStopped && !legacyFileValid) {
            android.util.Log.e("ControlPanelNext", "Screen recording output is empty; discarding it")
            android.widget.Toast.makeText(this, "فشل حفظ التسجيل: ملف الفيديو فارغ", android.widget.Toast.LENGTH_LONG).show()
        } else if (!saved && recording) {
            android.widget.Toast.makeText(this, "تعذر إكمال تسجيل الشاشة", android.widget.Toast.LENGTH_LONG).show()
        }
        recording = false
        releaseCapture()
        cleanupOutput(deleteIncomplete = !saved)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releaseCapture() {
        runCatching { virtualDisplay?.release() }; virtualDisplay = null
        runCatching { recorder?.reset() }; runCatching { recorder?.release() }; recorder = null
        runCatching { projection?.stop() }; projection = null
    }

    private fun cleanupOutput(deleteIncomplete: Boolean) {
        // Close the writer before publishing the MediaStore row so the gallery never
        // observes a video whose file descriptor is still open for recording.
        runCatching { outputDescriptor?.close() }
        outputDescriptor = null
        if (Build.VERSION.SDK_INT >= 29) {
            outputUri?.let { uri ->
                if (deleteIncomplete) {
                    runCatching { contentResolver.delete(uri, null, null) }
                } else {
                    runCatching {
                        val values = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                        val updatedRows = contentResolver.update(uri, values, null, null)
                        check(updatedRows > 0) { "MediaStore did not publish the recorded video" }
                    }.onFailure { error ->
                        android.util.Log.e("ControlPanelNext", "Unable to publish recorded video", error)
                        runCatching { contentResolver.delete(uri, null, null) }
                    }
                }
            }
        } else if (deleteIncomplete) {
            runCatching { outputFile?.delete() }
        }
        outputUri = null
        outputFile = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "تسجيل الشاشة", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val stop = PendingIntent.getService(this, 2, Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("لوحة التحكم")
            .setContentText(message)
            .setContentIntent(open)
            .setOngoing(recording)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stop)
            .build()
    }

    override fun onDestroy() {
        if (recording) {
            stopRecording()
        } else {
            // Prevent the projection's onStop callback from re-entering teardown.
            stopping = true
            releaseCapture()
            // Do not leave an unpublished MediaStore row if the service is torn down mid-setup.
            cleanupOutput(deleteIncomplete = true)
        }
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.controlpanel.next.recording.START"
        const val ACTION_STOP = "com.controlpanel.next.recording.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        private const val CHANNEL_ID = "screen_recording"
        private const val NOTIFICATION_ID = 701
    }
}
