plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.controlpanel.next"
    compileSdk = 35
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    flavorDimensions += "edition"
    productFlavors {
        create("user") {
            dimension = "edition"
            applicationIdSuffix = ".user"
            versionNameSuffix = "-user"
            buildConfigField("boolean", "DEVELOPER_EDITION", "false")
        }
        create("developer") {
            dimension = "edition"
            applicationIdSuffix = ".developer"
            versionNameSuffix = "-developer"
            buildConfigField("boolean", "DEVELOPER_EDITION", "true")
        }
    }
    buildFeatures { compose = true; buildConfig = true }
    defaultConfig {
        applicationId = "com.controlpanel.next"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "0.6.1"
    }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
    compileOnly("de.robv.android.xposed:api:82")
}
